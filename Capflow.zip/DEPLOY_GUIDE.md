# CapFlow — Deployment Guide
## How to get your app live on Railway (free, ~15 minutes)

---

## WHAT YOU HAVE

```
capflow/
├── backend/
│   ├── main.py          ← All API routes
│   ├── models.py        ← Database table definitions
│   ├── database.py      ← DB connection
│   ├── schemas.py       ← Request/response validation
│   ├── seed.py          ← Creates default admin + lenders
│   ├── requirements.txt ← Python packages
│   └── Procfile         ← Tells Railway how to start the app
└── frontend/
    └── index.html       ← Your complete frontend (one file)
```

---

## STEP 1 — Create accounts (free)

1. **GitHub**: https://github.com — sign up (free)
2. **Railway**: https://railway.app — sign up with GitHub (free tier = $5 credit/month, enough for this)

---

## STEP 2 — Push code to GitHub

1. Go to https://github.com/new and create a new repo called `capflow`
2. On your computer, open Terminal (Mac) or Command Prompt (Windows)
3. Run these commands:

```bash
cd capflow/backend          # navigate to the backend folder
git init
git add .
git commit -m "Initial CapFlow backend"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/capflow.git
git push -u origin main
```

---

## STEP 3 — Deploy backend on Railway

1. Go to https://railway.app and click **"New Project"**
2. Choose **"Deploy from GitHub repo"** → select your `capflow` repo
3. Railway will detect Python automatically and start deploying

### Add PostgreSQL database:
4. In your Railway project, click **"+ New"** → **"Database"** → **"PostgreSQL"**
5. Railway will automatically create a `DATABASE_URL` variable — your app uses this automatically!

### Set environment variables:
6. Click your backend service → **"Variables"** tab → Add:
   - `SECRET_KEY` = `some-long-random-string-change-this-123!`
   - Railway auto-sets `PORT` and `DATABASE_URL` for you ✓

7. Your app will redeploy. Click **"View Logs"** to watch it start up.
8. Once live, copy your URL — it looks like: `https://capflow-production-xxxx.railway.app`

---

## STEP 4 — Seed the database (one time only)

In Railway, click your backend service → **"Settings"** → scroll to **"Deploy"** → add a one-time command:

```
python seed.py
```

This creates:
- ✓ All 6 lenders (Apex Capital, GroFund, etc.)
- ✓ Default admin: `admin@capflow.co.za` / `CapFlow2026!`

**⚠️ Change the admin password immediately after first login!**

---

## STEP 5 — Connect your frontend

1. Open `frontend/index.html` in any text editor (Notepad, VS Code, etc.)
2. Find this line near the top:
   ```javascript
   const API_BASE = "https://YOUR-APP.railway.app";
   ```
3. Replace with your actual Railway URL:
   ```javascript
   const API_BASE = "https://capflow-production-xxxx.railway.app";
   ```

---

## STEP 6 — Host your frontend

**Easiest option — Netlify (free):**
1. Go to https://netlify.com → sign up free
2. Drag and drop your `frontend/` folder onto the Netlify dashboard
3. You get a live URL like `https://capflow-abc123.netlify.app`
4. Optional: connect a custom domain (e.g. capflow.co.za) in Netlify settings

---

## STEP 7 — Test your live app

1. Open your Netlify URL
2. Submit a test application
3. Click **"Admin Login"** → use `admin@capflow.co.za` / `CapFlow2026!`
4. You should see the application appear in the dashboard
5. Try approving it and releasing a payment!

---

## YOUR API ENDPOINTS (for reference)

| Method | URL | What it does |
|--------|-----|-------------|
| POST | /api/apply | Business submits application |
| GET | /api/apply/{ref} | Business tracks application |
| POST | /api/auth/login | Admin login |
| GET | /api/admin/applications | List all applications |
| PATCH | /api/admin/applications/{id} | Update status |
| POST | /api/admin/applications/{id}/release-payment | Fund an application |
| GET | /api/admin/stats | Dashboard KPIs |
| GET | /api/admin/lenders | List lenders |
| POST | /api/admin/lenders | Add a lender |

You can test all endpoints at: `https://YOUR-APP.railway.app/docs` (Swagger UI, auto-generated!)

---

## NEXT STEPS (when you're ready)

- **Email notifications** — Add SendGrid to email applicants when their status changes
- **Document storage** — Add Cloudflare R2 or AWS S3 for actual file uploads
- **Multi-admin** — Add more admin users via `/api/auth/register`
- **Custom domain** — Point capflow.co.za to your Netlify frontend
- **POPIA compliance** — Add a privacy policy page and cookie consent banner

---

## NEED HELP?

- Railway docs: https://docs.railway.app
- FastAPI docs: https://fastapi.tiangolo.com
- Your API interactive docs: https://YOUR-APP.railway.app/docs
